from typing import Any
from django.db import models
# for signup login 
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
import datetime
from colorfield.fields import ColorField
from django.utils import timezone
from ckeditor.fields import RichTextField

    
# Create your models here.
class Category(models.Model):
    name=models.CharField(max_length=150)

    def __str__(self):
        return self.name
    
class Sub_category(models.Model):
    name=models.CharField(max_length=150)
    category=models.ForeignKey(Category,on_delete=models.CASCADE)
    
    def __str__(self):
        return self.category.name + " : " + self.name
    
class Brand(models.Model):
    name=models.CharField(max_length=200)
    def __str__(self):
        return self.name

class Size(models.Model):
    size=models.CharField(max_length=200)
    def __str__(self):
        return self.size
    
class Special_Sale_Offer(models.Model):
    sale_offer_name=models.CharField(max_length=200)
    def __str__(self):
        return self.sale_offer_name
    
class Slide(models.Model):
    image=models.ImageField(upload_to="ecommerce/slider_images")
    offers=models.ForeignKey(Special_Sale_Offer,on_delete=models.CASCADE,null=True,blank=True,default='')
    brand=models.ForeignKey(Brand,on_delete=models.CASCADE,null=True)
    product_name=models.CharField(max_length=150)
    # description=models.TextField(null=True,blank=True)
    description=RichTextField(default='',null=False)

    def __str__(self):
        return self.product_name


class Product(models.Model):
    TARGET_CHOICES = [
        ('men', 'Men'),
        ('women', 'Women'),
        ('everyone', 'Everyone'),
        ('boys', 'Boys'),
        ('girls', 'Girls'),
        ('unisex_adults', 'Unisex Adults'),
        ('kids', 'Kids'),
        ('--','--')
    ]
    category=models.ForeignKey(Category,on_delete=models.CASCADE,null=False,default='') # Link Category with Product
    sub_category=models.ForeignKey(Sub_category,on_delete=models.CASCADE,null=False,default='') # Linksub Category with Product
    brand=models.ForeignKey(Brand,on_delete=models.CASCADE,null=True,blank=True)
    name=models.CharField(max_length=150)
    product_code=models.CharField(max_length=150,null=True,blank=True)
    special_offers=models.ForeignKey(Special_Sale_Offer,on_delete=models.CASCADE,null=True,blank=True,default='')
    target_audience = models.CharField(max_length=15, choices=TARGET_CHOICES, default='everyone')
    # description=models.TextField(null=True)
    description=RichTextField(default='',null=True)
    image=models.ImageField(upload_to="ecommerce/pimg")
    price=models.IntegerField()
    size=models.ForeignKey(Size,on_delete=models.CASCADE,null=True)
    # color = models.CharField(max_length=7, default="#000000")  # Storing hex color code
    available_quantity=models.IntegerField(null=True)
    Date=models.DateField(auto_now_add=True)
    
    def __str__(self):
        return self.name
    
class UserCreateForm(UserCreationForm):
    email= forms.EmailField(required=True,label="Email",error_messages={"Exists":"This aready exists"})
    
    class Meta:
        model=User
        fields=("username","email","password1","password2")
        
    def __init__(self, *args: Any, **kwargs: Any):
        super(UserCreateForm,self).__init__(*args, **kwargs)
        
        self.fields['username'].widget.attrs['placeholder']='User Name'
        self.fields['email'].widget.attrs['placeholder']="Email"
        self.fields['password1'].widget.attrs['placeholder']='Password'
        self.fields['password2'].widget.attrs['placeholder']='Confirm Password'
        
    def save(self,commit=True):
        user=super(UserCreateForm,self).save(commit=False)
        user.email=self.cleaned_data['email']
        if commit:
            user.save()
        return user
    
    def clean_email(self):
        if User.objects.filter(email=self.cleaned_data['email']).exists():
            raise forms.ValidationError(self.fields["email"].error_message["exists"])
        return self.cleaned_data["email"]
    
class Contact(models.Model):
    name=models.CharField(max_length=150)
    email=models.EmailField(max_length=150)
    subject=models.CharField(max_length=150)
    message=models.TextField(max_length=150)

    def __str__(self):
        return self.name

class Order(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Confirmed', 'Confirmed'),
        ('Shipped', 'Shipped'),
        ('Delivered', 'Delivered'),
        ('Cancelled', 'Cancelled'),
    ]
    image=models.ImageField(upload_to="ecommerce/order/image")
    # product=models.ForeignKey(Product, on_delete=models.CASCADE)
    product=models.CharField(max_length=1000,default='')
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    price=models.IntegerField()
    quantity=models.CharField(max_length=5)
    total=models.CharField(max_length=1000,default='')
    address=models.TextField()
    phone=models.CharField(max_length=13)
    pincode=models.CharField(max_length=10)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    date = models.DateField(default=timezone.now)
    def __str__(self):
        return self.product

