from django.contrib import admin

# Register your models here.
from .models import Category,Sub_category,Product,Contact,Order,Brand,Special_Sale_Offer,Size,Slide

admin.site.register(Category)
admin.site.register(Sub_category)
admin.site.register(Product)
admin.site.register(Contact)
admin.site.register(Order)
admin.site.register(Brand)
admin.site.register(Special_Sale_Offer)
admin.site.register(Size)
admin.site.register(Slide)

