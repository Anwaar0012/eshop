from django.shortcuts import redirect, render,HttpResponse
from App.models import Category,Product, UserCreateForm,Contact,Order,Brand,Slide
from django.contrib.auth import authenticate,login
from App.models import UserCreationForm
from django.contrib.auth.decorators import login_required
from cart.cart import Cart
from django.contrib.auth.models import User
# for email confirmation 
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from django.db.models import Min,Max


def Index(request):
    # Fetch all necessary data
    category = Category.objects.all()
    brand = Brand.objects.all()
    slides = Slide.objects.all()

    # Get the min and max price for the range slider
    min_price = Product.objects.aggregate(Min('price'))
    max_price = Product.objects.aggregate(Max('price'))

    # Get filter values from request
    FilterPrice = request.GET.get('FilterPrice')
    categoryid = request.GET.get("category")
    brand_id = request.GET.get('brand')

    # Start with all products, then apply filters step-by-step
    product_queryset = Product.objects.all()

    # Apply price filter if present
    if FilterPrice:
        int_filterPrice = int(FilterPrice)
        product_queryset = product_queryset.filter(price__lte=int_filterPrice)

    # Apply category filter if present
    if categoryid:
        product_queryset = product_queryset.filter(sub_category=categoryid)

    # Apply brand filter if present
    if brand_id:
        product_queryset = product_queryset.filter(brand=brand_id)

    # Order products by most recent
    product_queryset = product_queryset.order_by("-id")
    # Example of adding a message (if needed)

    context = {
        "category": category,
        "product": product_queryset,
        "brand": brand,
        "slides": slides,
        "min_price": min_price['price__min'],
        "max_price": max_price['price__max'],
        "FilterPrice": FilterPrice,
    }

    return render(request, "index.html", context)

def signup(request):
    if request.method == "POST":
        form = UserCreateForm(request.POST)
        if form.is_valid():
            new_user = form.save()
            new_user = authenticate(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password1']
            )
            if new_user:
                login(request, new_user)
                return redirect('index')
            else:
                messages.error(request, "Authentication failed.")
        else:
            messages.error(request, "Invalid credentials or form data.")
    else:
        form = UserCreateForm()

    context = {
        "form": form,
    }
    
    return render(request, 'registration/signup.html', context)

@login_required
def profile(request):
    return render(request, 'registration/profile.html', {'user': request.user})

# shipping cart pip install dajango-shipping-cart 
from django.contrib import messages
@login_required(login_url="/accounts/login/")
def cart_add(request, id):
    cart = Cart(request)
    product = Product.objects.get(id=id)
    cart.add(product=product)
    

    # Add a success message
   
    return redirect("/cart/cart-detail/")


@login_required(login_url="/accounts/login/")
def item_clear(request, id):
    cart = Cart(request)
    product = Product.objects.get(id=id)
    cart.remove(product)
    return redirect("cart_detail")


@login_required(login_url="/accounts/login/")
def item_increment(request, id):
    cart = Cart(request)
    product = Product.objects.get(id=id)
    cart.add(product=product)
    return redirect("cart_detail")


@login_required(login_url="/accounts/login/")
def item_decrement(request, id):
    cart = Cart(request)
    product = Product.objects.get(id=id)
    cart.decrement(product=product)
    return redirect("cart_detail")


@login_required(login_url="/accounts/login/")
def cart_clear(request):
    cart = Cart(request)
    cart.clear()
    return redirect("cart_detail")


@login_required(login_url="/accounts/login/")
def cart_detail(request):
    return render(request, 'cart/cart_detail.html')

def Contact_Page(request):
    if request.method=='POST':
        contact=Contact(
            name=request.POST.get('name'),
            email=request.POST.get('email'),
            subject=request.POST.get('subject'),
            message=request.POST.get('subject')
        )
        contact.save()

    return render(request, 'contact.html')


def Checkout(request):
    if request.method == 'POST':
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        pincode = request.POST.get('pincode')
        cart = request.session.get('cart')
        uid = request.session.get("_auth_user_id")
        user = User.objects.get(pk=uid)

        order_details = ""
        grand_total = 0  # Initialize grand total
        
        
        for i in cart:
            
            # Calculating total for each item
            a = int(cart[i]['price'])
            b = quantity = cart[i]['quantity']
            total = a * b
            grand_total += total  # Add the item's total to the grand total
            
            order = Order(
                user=user,
                product=cart[i]['name'],
                price=cart[i]['price'],
                quantity=cart[i]['quantity'],
                image=cart[i]['image'],
                address=address,
                phone=phone,
                pincode=pincode,
                total=total,
                status='Pending'  # Set the initial status as 'Pending'
            )
            order.save()

            # Add order details to the email content
            order_details += f"Product: {cart[i]['name']}, Quantity: {cart[i]['quantity']}, Total: {total}\n"
        
        # 1. Send order confirmation email to the customer
        customer_subject = 'Order Confirmation'
        customer_message = f"Dear {user.username},\n\nThank you for your order! Here are the details of your order:\n\n{order_details}\nGrand Total: {grand_total}\n\nShipping Address: {address},\npostal code {pincode}\nPhone: {phone}\n\nWe will notify you once your order is shipped."
        from_email = settings.DEFAULT_FROM_EMAIL
        send_mail(customer_subject, customer_message, from_email, [user.email])

        # 2. Send a detailed notification to the admin (yourself) with customer info and grand total
        #admin_subject = 'New Order Received - Customer Details'
        #admin_message = f""" 
        #New order placed by {user.username}.

        #Customer Details:
        #Name: {user.username}
        #Email: {user.email}
        #Phone: {phone}
        #Address: {address}, {pincode}

        #Order Details:
        #{order_details}
        #Grand Total: {grand_total}
        #"""
        # Send the admin email to your Gmail
        #admin_recipient = ['anwaar786786@gmail.com']
        #send_mail(admin_subject, admin_message, from_email, admin_recipient)
        
        # Clear cart
        request.session['cart'] = {}

         # Pass order summary to checkout confirmation page
        context = {
            'user': user,
            'grand_total': grand_total,
            'order_details': order_details
        }

        return render(request, 'checkout.html', context)
    return render(request, 'checkout.html')
    #     return redirect('index')
    
    # return render(request, 'checkout.html')



@login_required
def your_order(request):
    uid=request.session.get("_auth_user_id")
    user=User.objects.get(pk=uid)
    order=Order.objects.filter(user=user)
    # print(user,order)
    context={
        "order":order
    }
    return render(request,'order.html',context)


def Product_Page(request):
    # Fetch all necessary data
    category = Category.objects.all()
    brand = Brand.objects.all()
    slides = Slide.objects.all()

    # Get the min and max price for the range slider
    min_price = Product.objects.aggregate(Min('price'))
    max_price = Product.objects.aggregate(Max('price'))

    # Get filter values from request
    FilterPrice = request.GET.get('FilterPrice')
    categoryid = request.GET.get("category")
    brand_id = request.GET.get('brand')

    # Start with all products, then apply filters step-by-step
    product_queryset = Product.objects.all()

    # Apply price filter if present
    if FilterPrice:
        int_filterPrice = int(FilterPrice)
        product_queryset = product_queryset.filter(price__lte=int_filterPrice)

    # Apply category filter if present
    if categoryid:
        product_queryset = product_queryset.filter(sub_category=categoryid)

    # Apply brand filter if present
    if brand_id:
        product_queryset = product_queryset.filter(brand=brand_id)

    # Order products by most recent
    product_queryset = product_queryset.order_by("-id")
    # Example of adding a message (if needed)

    context = {
        "category": category,
        "product": product_queryset,
        "brand": brand,
        "slides": slides,
        "min_price": min_price['price__min'],
        "max_price": max_price['price__max'],
        "FilterPrice": FilterPrice,
    }
    return render(request,'product.html',context)

def Product_Detail(request,id):
    product=Product.objects.filter(pk=id).first()
    
    context={"product":product}
   
    return render(request,'product_detail.html',context)
def Search_page(request):
    query=request.GET['query']
    product=Product.objects.filter(name__icontains=query)
    context={"product":product}
    return render(request,'search.html',context)




@staff_member_required
def All_Orders(request):
    orders = Order.objects.all()
    context = {
        "orders": orders
    }
    return render(request, 'admin_orders.html', context)

# def product_list(request):
#     products = Product.objects.all()

#     # Get the min and max price from the request
#     min_price = request.GET.get('min_price', 0)
#     max_price = request.GET.get('max_price', 600)

#     # Filter products based on price range
#     products = products.filter(price__gte=min_price, price__lte=max_price)

#     context = {
#         'products': products,
#     }
#     return render(request, 'product_list.html', context)

# def product_list(request):
#     # Get the min and max price from the request, default to 1,000 to 100,000
#     min_price = request.GET.get('min_price', 1000)
#     max_price = request.GET.get('max_price', 100000)

#     # Filter products based on the price range
#     products = Product.objects.filter(price__gte=min_price, price__lte=max_price)

#     context = {
#         'products': products,
#     }
#     return render(request, 'product_list.html', context)

# def product_detail(request, pk):
#     product = Product.objects.get(pk=pk)
#     return render(request, 'product_detail.html', {'product': product})





