from pathlib import Path
import os

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/5.0/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-cx#7s94%%xh)cj!=-+ar+gwk-vne9mcf)-j8dhp7fwmzz(r&7%'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = []


# Application definition

INSTALLED_APPS = [
    'django.contrib.humanize',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'App.apps.AppConfig',
    'cart',
    "ckeditor",
    "ckeditor_uploader"
]
# for shopping cart 
CART_SESSION_ID = 'cart'

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'eshop.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',  # Ensure this is included
                'cart.context_processor.cart_total_amount',  # For shopping cart 
            ],
        },
    },
]

WSGI_APPLICATION = 'eshop.wsgi.application'


# Database
# https://docs.djangoproject.com/en/5.0/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# Password validation
# https://docs.djangoproject.com/en/5.0/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization
# https://docs.djangoproject.com/en/5.0/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/5.0/howto/static-files/
STATIC_URL = '/static/'  # This is the URL prefix for static files
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')  # Where static files will be collected

# These are directories where Django will look for additional static files
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')] 
# STATIC_URL = 'static/'
# STATIC_ROOT = '/static/'
# STATICFILES_DIRS=[os.path.join(BASE_DIR,'static')]
MEDIA_URL='/media/'
MEDIA_ROOT=os.path.join(BASE_DIR,'media')
# Default primary key field type
# https://docs.djangoproject.com/en/5.0/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# redirect urls
LOGIN_URL = 'login' 
LOGIN_REDIRECT_URL='index'
LOGOUT_REDIRECT_URL='index'
#  mail sending setup 
# EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
# EMAIL_USE_TLS = True
# EMAIL_HOST = 'smtp.gmail.com'
# EMAIL_PORT = 587
# EMAIL_HOST_USER = 'anwaar786786@gmail.com'
# EMAIL_HOST_PASSWORD = '202462'

# EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'

# Host for sending e-mail.
# EMAIL_HOST = 'localhost'

# Port for sending e-mail.
# EMAIL_PORT = 1025

# Optional SMTP authentication information for EMAIL_HOST.
# EMAIL_HOST_USER = 'anwaar786786@gmail.com'
# EMAIL_HOST_PASSWORD = '202462'
# EMAIL_USE_TLS = False
# Email configuration for Gmail SMTP
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
# EMAIL_HOST_USER = 'anwaar786786@gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_USE_SSL = False
EMAIL_HOST_USER = 'anwaar786786@gmail.com'  # Your Gmail address
EMAIL_HOST_PASSWORD = 'cktqyozobwsokaoe'         # Your Gmail App Password
DEFAULT_FROM_EMAIL = 'anwaar786786@gmail.com'


CKEDITOR_UPLOAD_PATH="Media/uploades"
CKEDOTOR_IMAGE_BACKEND="Pillow"
CKEDITOR_THUMBNAIL_SIZE=(300,300)
CKEDITOR_IMAGE_QUALITY=40
CKEDITOR_BROWSE_SHOW_DIR=True
CKEDITOR_ALLOW_NONIMAGE_FILES=True
CKEDITOR_UPLOAD_SLUGIFY_FILENAME=False
CKEDITOR_JQUERY_URL = "http://libs.baidu.com/jquery/2.0.3/jquery.min.js"

# Custom toolbar configuration
CUSTOM_TOOLBAR = [
    {
        "name": "document",
        "items": ["Source", "-", "Save", "NewPage", "Preview", "Print", "-", "Templates"],
    },
    {
        "name": "clipboard",
        "items": ["Cut", "Copy", "Paste", "PasteText", "PasteFromWord", "-", "Undo", "Redo"],
    },
    {
        "name": "editing",
        "items": ["Find", "Replace", "-", "SelectAll", "-", "Scayt"],
    },
    "/",
    {
        "name": "basicstyles",
        "items": ["Bold", "Italic", "Underline", "Strike", "Subscript", "Superscript", "-", "RemoveFormat"],
    },
    {
        "name": "paragraph",
        "items": ["NumberedList", "BulletedList", "-", "Outdent", "Indent", "-", "Blockquote"],
    },
    {
        "name": "links",
        "items": ["Link", "Unlink", "Anchor"],
    },
    {
        "name": "insert",
        "items": ["Image", "Table", "HorizontalRule", "Smiley", "SpecialChar", "PageBreak"],
    },
    "/",
    {
        "name": "styles",
        "items": ["Styles", "Format", "Font", "FontSize"],
    },
    {
        "name": "colors",
        "items": ["TextColor", "BGColor"],
    },
    {
        "name": "tools",
        "items": ["Maximize", "ShowBlocks"],
    },
]

CKEDITOR_CONFIGS = {
    "default": {
        "toolbar": [
            {"name": "document", "items": ["Source", "-", "Save", "NewPage", "Preview", "Print", "-", "Templates"]},
            {"name": "clipboard", "items": ["Cut", "Copy", "Paste", "PasteText", "PasteFromWord", "-", "Undo", "Redo"]},
            {"name": "editing", "items": ["Find", "Replace", "-", "SelectAll", "-", "Scayt"]},
            "/",
            {"name": "basicstyles", "items": ["Bold", "Italic", "Underline", "Strike", "Subscript", "Superscript", "-", "RemoveFormat"]},
            {"name": "paragraph", "items": ["NumberedList", "BulletedList", "-", "Outdent", "Indent", "-", "Blockquote", "Div"]},
            {"name": "links", "items": ["Link", "Unlink", "Anchor"]},
            {"name": "insert", "items": ["Image", "Table", "HorizontalRule", "Smiley", "SpecialChar", "PageBreak"]},
            "/",
            {"name": "styles", "items": ["Styles", "Format", "Font", "FontSize"]},
            {"name": "colors", "items": ["TextColor", "BGColor"]},
            {"name": "tools", "items": ["Maximize", "ShowBlocks"]},
            {'name': 'clipboard', 'items': ['Cut', 'Copy', 'Paste', 'Undo', 'Redo']}
        ],
        # "height": 300,
        # "width": "100%",
        # "extraPlugins": ",".join(["uploadimage", "image2", "div"]),  # Enables the Div plugin
    },
}
